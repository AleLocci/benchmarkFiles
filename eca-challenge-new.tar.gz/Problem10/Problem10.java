import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Problem10 {
	private String a4 = "e";
	private int a1 = 23;
	private String a12 = "e";
	private int a19 = 9;
	private int a10 = 0;

		private String[] inputs = {"C","D","E","F","B"};

		public String[] getInputs(){
			return inputs;
		}

	public String calculateOutput(String input) {
		if((((((a10==4) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_57" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_48" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "globalError" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_50" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_15" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_28" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_12" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_58" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_24" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_29" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_26" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_42" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_55" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_47" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_41" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_46" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_49" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_56" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_6" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_32" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_39" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_21" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_20" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_19" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_17" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_14" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_38" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_16" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_30" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_43" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_3" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_22" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_45" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_36" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_8" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_52" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_53" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_31" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_33" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_7" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_23" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_0" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_10" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_40" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_51" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_35" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_5" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_1" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_37" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_13" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_9" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_44" );
		}
		if((((((a10==4) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_18" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_2" );
		}
		if((((((a10==2) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_27" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_11" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==8))){
			throw new IllegalStateException( "error_54" );
		}
		if((((((a10==3) && (a12.equals("e"))) &&  218 < a1 ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_34" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e"))) && (a19==7))){
			throw new IllegalStateException( "error_25" );
		}
		if((((((a10==0) && (a12.equals("e"))) &&  a1 <=  -13 ) && (a4.equals("e"))) && (a19==9))){
			throw new IllegalStateException( "error_59" );
		}
		if((((((a10==1) && (a12.equals("e"))) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e"))) && (a19==6))){
			throw new IllegalStateException( "error_4" );
		}

	    if(((a12.equals("e")) && ((( 218 < a1  && ((a19==9) && input.equals(inputs[2]))) && (a10==1)) && (a4.equals("e"))))){

	    	a1 = ((((a1 * 9)/ 10) + 58620) - 603783);
	    	a10 = 4; 
	    	a19 = 8; 

	    	 return null;
	    } else if((((a4.equals("e")) && ((a19==9) && (input.equals(inputs[4]) && (((a10==3) &&  218 < a1 ) || ((a10==4) &&  a1 <=  -13 ))))) && (a12.equals("e")))){

	    	a1 = ((((a1 % 299993)+ -300005) - 1) - 1);
	    	a10 = 1; 

	    	 return null;
	    } else if(((a10==0) && ((a12.equals("e")) && (((input.equals(inputs[2]) && ( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) )) && (a19==10)) && (a4.equals("e")))))){

	    	a1 = (((((a1 % 299890)+ 300108) - -1) + -309315) - -309317);
	    	a10 = 1; 
	    	a19 = 7; 

	    	 return null;
	    } else if(((a19==9) && ((((a4.equals("e")) && (input.equals(inputs[4]) && ( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) ))) && (a12.equals("e"))) && (a10==2)))){

	    	a1 = ((((a1 % 299993)+ -300005) * 1) + -1);
	    	 return "Y";
	    } else if(((a12.equals("e")) && ((((a4.equals("e")) && (input.equals(inputs[0]) && ( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) ))) && (a10==2)) && (a19==9)))){

	    	a1 = (((((a1 % 299993)+ -300005) * 1) + 533674) - 533676);
	    	 return "V";
	    } else if(((a19==9) && (((a10==1) && ((a12.equals("e")) && (input.equals(inputs[4]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) )))) && (a4.equals("e"))))){

	    	a1 = (((((a1 * 5) + 59655) * 5) % 25)+ 12);
	    	a19 = 10; 

	    	 return "Z";
	    } else if((((a12.equals("e")) && ((a19==9) && ((input.equals(inputs[0]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) )) && (a4.equals("e"))))) && (a10==3))){

	    	a1 = ((((a1 - -133866) + -357620) / 5) + 265622);
	    	a10 = 0; 

	    	 return null;
	    } else if(((((a4.equals("e")) && ((a19==10) && ((a10==1) && input.equals(inputs[4])))) && (a12.equals("e"))) &&  218 < a1 )){


	    	a19 = 9; 

	    	 return "V";
	    } else if(((a4.equals("e")) && (((a12.equals("e")) && ( 218 < a1  && ((a19==9) && input.equals(inputs[0])))) && (a10==4)))){


	    	 return "X";
	    } else if((((a12.equals("e")) && (  ((-13 < a1) && (38 >= a1))  && ((input.equals(inputs[0]) && (a19==10)) && (a4.equals("e"))))) && (a10==1))){

	    	a1 = ((((a1 - -221565) * 10)/ 9) / 5);
	    	a19 = 9; 

	    	 return "V";
	    } else if((((a4.equals("e")) && (((a12.equals("e")) && ( 218 < a1  && input.equals(inputs[3]))) && (a19==10))) && (a10==1))){

	    	a1 = (((a1 - 600149) - 12) + -58);
	    	 return null;
	    } else if((((a12.equals("e")) && ((((a19==9) && input.equals(inputs[1])) &&  218 < a1 ) && (a10==1))) && (a4.equals("e")))){


	    	 return "V";
	    } else if((((a4.equals("e")) && ((a12.equals("e")) && ((((a10==3) &&  218 < a1 ) || ((a10==4) &&  a1 <=  -13 )) && input.equals(inputs[1])))) && (a19==9))){

	    	a1 = ((((a1 % 89)+ 128) + -1) - 0);
	    	a10 = 3; 

	    	 return null;
	    } else if(((a19==10) && (((a4.equals("e")) && (((((a10==0) &&   ((38 < a1) && (218 >= a1)) ) || ((a10==0) &&  218 < a1 )) || ((a10==1) &&  a1 <=  -13 )) && input.equals(inputs[2]))) && (a12.equals("e"))))){

	    	a1 = (((((a1 - 0) * 9)/ 10) % 25)- -12);
	    	a10 = 2; 
	    	a19 = 8; 

	    	 return null;
	    } else if(((a12.equals("e")) && ((a19==9) && ((input.equals(inputs[3]) && (((a10==3) &&  218 < a1 ) || ( a1 <=  -13  && (a10==4)))) && (a4.equals("e")))))){

	    	a1 = ((((a1 + 0) % 299890)+ 300108) + 0);
	    	a10 = 2; 

	    	 return null;
	    } else if((((a19==10) && ((a12.equals("e")) && ((((a10==1) &&  a1 <=  -13 ) || ((  ((38 < a1) && (218 >= a1))  && (a10==0)) || ((a10==0) &&  218 < a1 ))) && input.equals(inputs[0])))) && (a4.equals("e")))){

	    	a1 = ((((a1 % 299993)- 300005) - 0) - 2);
	    	a10 = 2; 
	    	a19 = 9; 

	    	 return "V";
	    } else if(((a19==9) && ((a12.equals("e")) && (((( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) ) && input.equals(inputs[2])) && (a4.equals("e"))) && (a10==2))))){

	    	a1 = ((((a1 % 299890)+ 300108) * 1) * 1);
	    	a10 = 0; 
	    	a19 = 8; 

	    	 return null;
	    } else if(((a12.equals("e")) && ((a4.equals("e")) && (((( a1 <=  -13  && (a10==1)) || (((a10==0) &&   ((38 < a1) && (218 >= a1)) ) || ( 218 < a1  && (a10==0)))) && input.equals(inputs[4])) && (a19==10))))){

	    	a1 = ((((a1 % 25)+ 12) - -2) / 5);
	    	a10 = 2; 
	    	a19 = 9; 

	    	 return "V";
	    } else if(((a19==9) && ((a4.equals("e")) && ((((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[0])) && (a10==1)) && (a12.equals("e")))))){

	    	a1 = (((a1 / 5) + 105416) + 61704);
	    	a10 = 4; 

	    	 return "X";
	    } else if(((a4.equals("e")) && (((a12.equals("e")) && ((a19==9) && (input.equals(inputs[3]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) )))) && (a10==4)))){

	    	a1 = (((((a1 - 44798) + -168742) * 2) % 89)+ 207);
	    	 return null;
	    } else if(((a10==0) && ((a12.equals("e")) && (((( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) ) && input.equals(inputs[0])) && (a19==10)) && (a4.equals("e")))))){

	    	a1 = (((((a1 % 25)+ 13) - 1) + -16025) - -16025);
	    	 return null;
	    } else if((((a12.equals("e")) && (((input.equals(inputs[2]) && (a19==10)) &&   ((38 < a1) && (218 >= a1)) ) && (a4.equals("e")))) && (a10==1))){

	    	a1 = ((((a1 + 381077) % 25)- -1) / 5);
	    	a10 = 2; 
	    	a19 = 7; 

	    	 return null;
	    } else if(((a19==9) && ((a4.equals("e")) && ((a10==1) && ((input.equals(inputs[2]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) )) && (a12.equals("e"))))))){

	    	a1 = (((a1 + -438195) * 1) * 1);
	    	a10 = 2; 
	    	a19 = 8; 

	    	 return null;
	    } else if(((((a10==1) && ((input.equals(inputs[2]) &&  218 < a1 ) && (a4.equals("e")))) && (a19==10)) && (a12.equals("e")))){

	    	a1 = (((((a1 % 89)- -93) * 5) % 89)- -56);
	    	a10 = 4; 
	    	a19 = 8; 

	    	 return null;
	    } else if((  ((38 < a1) && (218 >= a1))  && (((a4.equals("e")) && ((a19==10) && ((a10==1) && input.equals(inputs[1])))) && (a12.equals("e"))))){

	    	a1 = ((((a1 * 57)/ 10) * 5) * 5);
	    	a19 = 9; 

	    	 return "X";
	    } else if(((a19==9) && (((a4.equals("e")) && ((((a10==3) &&  218 < a1 ) || ( a1 <=  -13  && (a10==4))) && input.equals(inputs[2]))) && (a12.equals("e"))))){

	    	a1 = ((((((a1 % 25)- -12) - 0) * 5) % 25)- -13);
	    	a10 = 3; 
	    	a19 = 6; 

	    	 return null;
	    } else if((((a12.equals("e")) && ((a19==9) && ((((a10==3) &&  a1 <=  -13 ) || (((a10==2) &&   ((38 < a1) && (218 >= a1)) ) || ( 218 < a1  && (a10==2)))) && input.equals(inputs[3])))) && (a4.equals("e")))){

	    	a1 = ((((a1 - 0) % 299890)- -300108) - -1);
	    	a10 = 2; 

	    	 return null;
	    } else if(((a19==9) && (((input.equals(inputs[1]) && (( 218 < a1  && (a10==0)) || ((a10==1) &&  a1 <=  -13 ))) && (a12.equals("e"))) && (a4.equals("e"))))){

	    	a1 = (((((a1 / 5) % 89)- -128) / 5) + 34);
	    	a10 = 0; 
	    	a19 = 8; 

	    	 return null;
	    } else if(((a4.equals("e")) && (((a12.equals("e")) && (((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[1])) && (a19==9))) && (a10==0)))){

	    	a1 = (((a1 + -15535) - 211896) / 5);
	    	a10 = 2; 

	    	 return "V";
	    } else if((((a19==9) && ((input.equals(inputs[3]) && (( 218 < a1  && (a10==0)) || ( a1 <=  -13  && (a10==1)))) && (a4.equals("e")))) && (a12.equals("e")))){

	    	a1 = (((((a1 % 25)- -13) - 42605) / 5) - -8517);
	    	a10 = 3; 

	    	 return "Z";
	    } else if((((a12.equals("e")) && ((a19==9) && ((a10==2) && (input.equals(inputs[3]) && ( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) ))))) && (a4.equals("e")))){

	    	a1 = ((((a1 / 5) % 25)+ 13) / 5);
	    	 return "Y";
	    } else if(((a12.equals("e")) && ((a4.equals("e")) && ( 218 < a1  && (((a10==1) && input.equals(inputs[1])) && (a19==10)))))){

	    	a1 = (((((a1 * 9)/ 10) * -1)/ 10) * 5);
	    	a10 = 2; 
	    	a19 = 9; 

	    	 return "X";
	    } else if((((((a12.equals("e")) && (input.equals(inputs[1]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ))) && (a19==9)) && (a4.equals("e"))) && (a10==3))){

	    	a1 = (((a1 * 5) - 196556) + 94277);
	    	 return null;
	    } else if(( 218 < a1  && ((((input.equals(inputs[0]) && (a10==1)) && (a12.equals("e"))) && (a4.equals("e"))) && (a19==10)))){

	    	a1 = ((((a1 % 25)- 10) - 1) / 5);
	    	a10 = 0; 

	    	 return null;
	    } else if(((a12.equals("e")) && (((a19==9) && ((((a10==0) &&  218 < a1 ) || ( a1 <=  -13  && (a10==1))) && input.equals(inputs[2]))) && (a4.equals("e"))))){

	    	a1 = ((((a1 % 299993)- 300005) + -1) - 1);
	    	a10 = 3; 

	    	 return "U";
	    } else if(((a10==1) && ((a4.equals("e")) && ((((a12.equals("e")) && input.equals(inputs[4])) && (a19==9)) &&  218 < a1 )))){

	    	a1 = ((((((a1 % 89)+ 74) - -21) * 5) % 89)- -118);
	    	a19 = 10; 

	    	 return "Y";
	    } else if((((a10==1) && (((a12.equals("e")) && ((a19==10) && input.equals(inputs[1]))) &&   ((-13 < a1) && (38 >= a1)) )) && (a4.equals("e")))){

	    	a1 = (((a1 - -575828) - -5011) + 9014);
	    	a19 = 9; 

	    	 return "X";
	    } else if(((a12.equals("e")) && ((((a10==1) && (  ((-13 < a1) && (38 >= a1))  && input.equals(inputs[4]))) && (a4.equals("e"))) && (a19==10)))){


	    	 return "Z";
	    } else if((((a4.equals("e")) && ((input.equals(inputs[1]) && (((  ((38 < a1) && (218 >= a1))  && (a10==2)) || ((a10==2) &&  218 < a1 )) || ( a1 <=  -13  && (a10==3)))) && (a19==9))) && (a12.equals("e")))){

	    	a1 = (((a1 / 5) - -435872) + 13710);
	    	a10 = 0; 

	    	 return null;
	    } else if((((a10==0) && ((a12.equals("e")) && ((input.equals(inputs[1]) && ( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) )) && (a19==10)))) && (a4.equals("e")))){

	    	a1 = ((((a1 % 25)+ 13) / 5) - -2);
	    	 return "Z";
	    } else if((((a19==10) && ((a10==1) && ((a12.equals("e")) && (  ((-13 < a1) && (38 >= a1))  && input.equals(inputs[2]))))) && (a4.equals("e")))){

	    	a1 = (((a1 + -283353) / 5) + -495232);
	    	a10 = 0; 
	    	a19 = 6; 

	    	 return null;
	    } else if(((a19==9) && ((a4.equals("e")) && ((input.equals(inputs[2]) && (((  ((38 < a1) && (218 >= a1))  && (a10==2)) || ((a10==2) &&  218 < a1 )) || ((a10==3) &&  a1 <=  -13 ))) && (a12.equals("e")))))){

	    	a1 = ((((a1 % 299890)- -300108) + 2) + 0);
	    	a10 = 2; 

	    	 return "U";
	    } else if((((((  ((38 < a1) && (218 >= a1))  && input.equals(inputs[0])) && (a10==1)) && (a12.equals("e"))) && (a4.equals("e"))) && (a19==10))){

	    	a1 = ((((a1 * 5) - -287099) - 723016) + 616783);
	    	a10 = 4; 
	    	a19 = 9; 

	    	 return null;
	    } else if((((a10==4) && ( 218 < a1  && ((input.equals(inputs[1]) && (a12.equals("e"))) && (a4.equals("e"))))) && (a19==9))){


	    	a10 = 1; 

	    	 return "X";
	    } else if(((a12.equals("e")) && ((((input.equals(inputs[3]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) )) && (a19==9)) && (a4.equals("e"))) && (a10==0)))){

	    	a1 = (((((a1 + -272193) - -47605) - -570122) % 89)+ 110);
	    	a10 = 1; 

	    	 return "Y";
	    } else if(((a4.equals("e")) && (((((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[2])) && (a12.equals("e"))) && (a19==9)) && (a10==4)))){

	    	a1 = (((a1 + 566454) + 1842) + 23814);
	    	a10 = 2; 
	    	a19 = 8; 

	    	 return null;
	    } else if((((a4.equals("e")) && ((((((a10==2) &&   ((38 < a1) && (218 >= a1)) ) || ((a10==2) &&  218 < a1 )) || ( a1 <=  -13  && (a10==3))) && input.equals(inputs[4])) && (a19==9))) && (a12.equals("e")))){

	    	a1 = (((((a1 % 299890)- -300108) + 0) + -140588) + 140590);
	    	a10 = 0; 

	    	 return "Z";
	    } else if(( 218 < a1  && ((((a12.equals("e")) && ((a19==9) && input.equals(inputs[4]))) && (a10==4)) && (a4.equals("e"))))){


	    	a10 = 1; 

	    	 return "V";
	    } else if((((((input.equals(inputs[2]) && (a4.equals("e"))) &&  218 < a1 ) && (a10==4)) && (a19==9)) && (a12.equals("e")))){

	    	a1 = (((((a1 % 25)+ -8) * 5) % 25)+ 13);
	    	a10 = 1; 
	    	a19 = 7; 

	    	 return null;
	    } else if((((((a4.equals("e")) && (input.equals(inputs[3]) && (a10==1))) && (a12.equals("e"))) &&   ((38 < a1) && (218 >= a1)) ) && (a19==10))){

	    	a1 = (((a1 - -320095) * 1) - -173480);
	    	a19 = 9; 

	    	 return null;
	    } else if(((a4.equals("e")) && ((a10==1) && ((a19==9) && ((a12.equals("e")) && ((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[1]))))))){

	    	a1 = ((((a1 - 46038) + -455425) * 10)/ 9);
	    	a19 = 10; 

	    	 return "X";
	    } else if(((a4.equals("e")) && ((a19==9) && (((( a1 <=  -13  && (a10==3)) || ((  ((38 < a1) && (218 >= a1))  && (a10==2)) || ((a10==2) &&  218 < a1 ))) && input.equals(inputs[0])) && (a12.equals("e")))))){

	    	a1 = ((((a1 % 299890)- -300108) + 1) * 1);
	    	a10 = 0; 

	    	 return null;
	    } else if(((a4.equals("e")) && (((a19==9) && (((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[3])) && (a10==3))) && (a12.equals("e"))))){

	    	a1 = (((a1 - 559222) + -11915) - 28339);
	    	a10 = 1; 

	    	 return null;
	    } else if(((a12.equals("e")) && ((a19==9) && (((a4.equals("e")) && (input.equals(inputs[4]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ))) && (a10==3))))){

	    	a1 = (((a1 + 513169) / 5) - -374179);
	    	a10 = 0; 

	    	 return "Z";
	    } else if((((((input.equals(inputs[0]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) )) && (a10==0)) && (a19==9)) && (a4.equals("e"))) && (a12.equals("e")))){

	    	a1 = ((((a1 / 5) * 5) / 5) + 505228);
	    	a10 = 1; 

	    	 return "Y";
	    } else if(((((a12.equals("e")) && ((((a10==0) &&  218 < a1 ) || ((a10==1) &&  a1 <=  -13 )) && input.equals(inputs[4]))) && (a19==9)) && (a4.equals("e")))){

	    	a1 = ((((((a1 * 9)/ 10) % 299993)+ -300005) / 5) + -75819);
	    	a10 = 4; 

	    	 return "Z";
	    } else if((((a4.equals("e")) && ((((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[2])) && (a19==9)) && (a12.equals("e")))) && (a10==0))){

	    	a1 = (((a1 / 5) + 110755) + 220746);
	    	a10 = 1; 
	    	a19 = 8; 

	    	 return null;
	    } else if(((a12.equals("e")) && ((a19==9) && ((a10==1) && (( 218 < a1  && input.equals(inputs[0])) && (a4.equals("e"))))))){


	    	a19 = 10; 

	    	 return "Y";
	    } else if((((((input.equals(inputs[4]) && ( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) )) && (a19==10)) && (a10==0)) && (a4.equals("e"))) && (a12.equals("e")))){

	    	a1 = ((((a1 % 299890)+ 300108) - -1) + 0);
	    	a10 = 4; 
	    	a19 = 9; 

	    	 return null;
	    } else if((((a4.equals("e")) && (((input.equals(inputs[3]) && ( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) )) && (a19==10)) && (a12.equals("e")))) && (a10==0))){

	    	a1 = (((((a1 + 0) % 299993)- 300005) / 5) - 292229);
	    	 return null;
	    } else if((((((a4.equals("e")) && (  ((38 < a1) && (218 >= a1))  && input.equals(inputs[4]))) && (a12.equals("e"))) && (a10==1)) && (a19==10))){

	    	a1 = ((((a1 * 10)/ -9) * 5) - 333686);
	    	a10 = 4; 
	    	a19 = 6; 

	    	 return null;
	    } else if((((a4.equals("e")) && (((a19==9) && ((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[4]))) && (a12.equals("e")))) && (a10==4))){

	    	a1 = (((((a1 % 89)+ 129) - 1134) * -1)/ 10);
	    	a10 = 3; 

	    	 return null;
	    } else if((((a10==3) && (((a19==9) && ((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[2]))) && (a12.equals("e")))) && (a4.equals("e")))){

	    	a1 = ((((a1 - 287698) - 189392) % 89)+ 206);
	    	a10 = 2; 
	    	a19 = 7; 

	    	 return null;
	    } else if((((((a10==1) && ((a12.equals("e")) && input.equals(inputs[3]))) && (a19==10)) &&   ((-13 < a1) && (38 >= a1)) ) && (a4.equals("e")))){

	    	a1 = (((a1 / 5) - 367764) - -191971);
	    	a10 = 2; 
	    	a19 = 9; 

	    	 return "X";
	    } else if((((a4.equals("e")) && (((( a1 <=  -13  && (a10==1)) || (((a10==0) &&   ((38 < a1) && (218 >= a1)) ) || ( 218 < a1  && (a10==0)))) && input.equals(inputs[3])) && (a19==10))) && (a12.equals("e")))){

	    	a1 = (((((a1 * 9)/ 10) % 299993)+ -300005) - 1);
	    	a10 = 2; 
	    	a19 = 9; 

	    	 return "X";
	    } else if(((a4.equals("e")) && ((a19==9) && ((a12.equals("e")) && ((input.equals(inputs[4]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) )) && (a10==0)))))){

	    	a1 = (((a1 * 5) + 278443) - -239546);
	    	 return "Z";
	    } else if((((a12.equals("e")) && ((a10==1) && ( 218 < a1  && ((a19==9) && input.equals(inputs[3]))))) && (a4.equals("e")))){


	    	 return "X";
	    } else if(((a19==9) && (((a10==4) && ( 218 < a1  && ((a4.equals("e")) && input.equals(inputs[3])))) && (a12.equals("e"))))){


	    	a19 = 8; 

	    	 return null;
	    } else if(((a19==10) && ((a4.equals("e")) && ((a12.equals("e")) && (input.equals(inputs[1]) && ((((a10==0) &&   ((38 < a1) && (218 >= a1)) ) || ( 218 < a1  && (a10==0))) || ((a10==1) &&  a1 <=  -13 ))))))){

	    	a1 = ((((a1 % 299993)- 300005) * 1) + -3);
	    	a10 = 2; 
	    	a19 = 9; 

	    	 return "X";
	    } else if((((((( 218 < a1  && (a10==0)) || ((a10==1) &&  a1 <=  -13 )) && input.equals(inputs[0])) && (a4.equals("e"))) && (a12.equals("e"))) && (a19==9))){

	    	a1 = ((((((a1 / 5) % 25)+ 13) * 5) % 25)- -12);
	    	a10 = 4; 

	    	 return "V";
	    } else if((((a4.equals("e")) && ((a12.equals("e")) && (input.equals(inputs[0]) && (((a10==3) &&  218 < a1 ) || ( a1 <=  -13  && (a10==4)))))) && (a19==9))){

	    	a1 = ((((a1 - 0) - 0) / 5) - 247106);
	    	a10 = 4; 

	    	 return null;
	    } else if((((a10==1) && (((a12.equals("e")) && (input.equals(inputs[3]) && (  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ))) && (a4.equals("e")))) && (a19==9))){

	    	a1 = ((((a1 / 5) - -367248) * 1) - 890938);
	    	a10 = 0; 
	    	a19 = 10; 

	    	 return "Z";
	    } else if((((a10==4) && ((((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[1])) && (a4.equals("e"))) && (a19==9))) && (a12.equals("e")))){

	    	a1 = (((((a1 - -249982) + 317100) * 1) % 89)- -62);
	    	 return null;
	    } else if((((a4.equals("e")) && (((( a1 <=  -13  ||   ((-13 < a1) && (38 >= a1)) ) && input.equals(inputs[1])) && (a12.equals("e"))) && (a19==9))) && (a10==2))){

	    	a1 = ((((a1 % 299993)- 300005) * 1) - 3);
	    	 return "X";
	    } else if((((a12.equals("e")) && (((a10==4) && ((  ((-13 < a1) && (38 >= a1))  ||   ((38 < a1) && (218 >= a1)) ) && input.equals(inputs[0]))) && (a4.equals("e")))) && (a19==9))){

	    	a1 = ((((a1 + -121822) * 4) * 10)/ -9);
	    	a10 = 3; 

	    	 return null;
	    } 
	    throw new IllegalArgumentException("Current state has not transition for this input!");
	}
	public static void main(String[] args) throws Exception 
	{
			// default output
			String output = null;

			// init eca-System and input reader
            Problem10 eca = new Problem10();
            BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

			// main i/o-loop
            while(true)
            {
            	//read input
                String input = stdin.readLine();
                try{
                	 //operate eca engine
                	 output = eca.calculateOutput(input);
                	 if(output != null)
                	 	System.out.println(output);
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
	    	}
	}
}
